export const experiences = [
  {
    id: 1,
    title: 'MERN Stack Web Developer',
    company: "",
    duration: "(2023 - Present)"
  },
  {
    id: 2,
    title: "FullStack Developer",
    company: "Freelancer",
    duration: "(2023 - Present)"
  },
  {
    id: 3,
    title: "Self Employed",
    company: "Code and build something in everyday.",
    duration: "(2023 - Present)"
  }
]