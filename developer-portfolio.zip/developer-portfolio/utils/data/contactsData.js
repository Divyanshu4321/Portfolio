export const contactsData = {
    email: 'divyanshuparmar00@gmail.com',
    phone: '+917049567526',
    address: 'Arya Samaj Marg, Ujjain, India - 456001 ',
    github: 'https://github.com/Divyanshu4321',
    facebook: 'https://www.facebook.com/divyanshu.parmar.1291',
    linkedIn: 'https://www.linkedin.com/in/divyanshu-parmar-944088281/',
    twitter: 'https://twitter.com/Divyanshu_171',
    devUsername: "Divyanshu_171"
}