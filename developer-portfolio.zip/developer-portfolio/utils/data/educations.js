export const educations = [
  {
    id: 1,
    title: "Certified In Web Designing & Development",
    duration: "2023-2024",
    institution: "From Mantra Institute Ujjain",
  },
  {
    id: 2,
    title: "Bachelor Of Commerce(Computer Application)",
    duration: "Final Year Running",
    institution: "Advance Science & Arts Collage Ujjain",
  },
  {
    id: 3,
    title: "Freelancer",
    duration: "2023",
    institution: "",
  },
]